import groovy.io.FileType

def list = []

def dir = new File(".")
dir.eachFileRecurse (FileType.FILES) { file ->
  list << file
}

File filePrefix = new File("output_prefix.txt")
File fileSuffix = new File("output_suffix.txt")

def tokensListPrefix = []
def tokensListSuffix = []

list.each {
	if (it.path.contains('.stl'))
	{
		fileContents = it.getText("utf8").replaceAll("[^\\s\\p{L}0-9\\[\\]]", " ")

		def tokenized = fileContents.tokenize(' ')
		for (token in tokenized)
		{
			if (token.length() >= 3 && !token.matches(".*\\d.*"))
			{
				//println "[" + token + "]"
				//file << ("${token}\n")
				if (it.path.contains('Prefix'))
				{
					tokensListPrefix << token
				}
				else
				{
					tokensListSuffix << token
				}
			}
		}	  
	}
}

tokensListPrefix.unique()
for (token in tokensListPrefix)
{
	filePrefix << ("${token}\n")
}

tokensListSuffix.unique()
for (token in tokensListSuffix)
{
	fileSuffix << ("${token}\n")
}